<?php
error_reporting(0);
define('DB_HOST', 'https://www.thehrmpractitioners.com');
define('DB_USER', 'root');
define('DB_PASSWORD', 'QG684ffn');
define('DB_DATABASE', 'dwf');
//Connect to mysql server
$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
if(!$link) {
die('Failed to connect to server: ' . mysql_error());
}
//Select database
$db = mysql_select_db(DB_DATABASE);
if(!$db) {
die("Unable to select database");
}
ini_set('post_max_size', '64M');
$mainurl="http://www.thehrmpractitioners.com/dwf_new_1/";
?>
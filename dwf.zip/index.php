<!DOCTYPE html>

<html lang="en-gb" dir="ltr" class="com_content view-article itemid-723 j33 no-touch"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  <title>Disclose Without Fear!</title>

  <link rel="stylesheet" href="css/css-be258.css" type="text/css">

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

 </head>

 <body>



<div id="ja-content-mass-top" class="ja-content-mass-top container">

<div class="ja-slogan" style="min-height:550px;">

	<div class="row">

		<div class="span6 ">

<div class="span2 logo">

	      <div class="logo-image">

	        <h1>

	          <a href="/" title="Disclose Without Fear">

	            <span>Disclose Without Fear</span>

	          </a>

	        </h1>

	        <small class="site-slogan"></small>

	      </div>

	    </div>

<p style="text-align: center;"><img alt="" src="images/home-left.png" style="margin-top:50px;"></p>



<!--<p style="text-align: center;"><a href="#" title="Send your Inquiries.."><img style="margin-top:0px;" alt="" src="images/contact.png"></a><a href="feedback.php" title="Send your Inquiries.."><img style="margin-top:0px;" alt="" src="images/feedback.png"></a></p>-->

		</div>
		<div class="span6">
<p style="text-align: center; height:100px;"><a title="Admin Login" href="admin/"><img style="margin: 5px 20px;" src="images/admin_login.png" alt="Admin Login" /></a><a title="CAM Login" href="cam/"><img style="margin: 5px 20px;" src="images/cam_login.png" alt="CAM Login" /></a><a title="TS Login" href="ts/"><img style="margin: 5px 20px;" src="images/ts_login.png" alt="TS Login" /></a></p>
</div>
	</div>

</div>

<!-- //SLOGAN -->



</div>	

    

<!-- SLIDESHOW -->

<nav class="wrap t3-slideshow container">

  <div class="main-container">

    

  </div>

</nav>

<!-- //SLIDESHOW -->		

    

		

    <section id="t3-mainbody" class="container t3-mainbody ">
	
	

  <div class="row">

    

    <!-- MAIN CONTENT -->

    <div id="t3-content" class="t3-content span12">

      <div id="system-message-container">

	</div>



      

<div class="item-page clearfix">



		

	<!-- Article -->

	<article>

				

				<section class="article-content clearfix">

					<p style="text-align: left;"><span style="color: #000000;">© The HRM Practitioners LLP, 2014. All Rights Reserved</span> </p>				</section>

				

								</article>

	<!-- //Article -->







</div>

    </div>

    <!-- //MAIN CONTENT -->



        

    

  </div>

</section> 

    

    

<div class="ja-home">



  

  

</div>

    

    

<!-- NAV HELPER -->

<nav class="wrap t3-navhelper">

  <div class="container">

    

  </div>

</nav>

<!-- //NAV HELPER -->    

    

<!-- FOOTER -->

<footer>

	

		

  <section class="t3-copyright">

    <div class="container">

    	<div class="t3-copyright-poweredby">

	      

	      

      </div>

    </div>    

  </section>

  	    

</footer>

<!-- //FOOTER -->    

  



</body></html>
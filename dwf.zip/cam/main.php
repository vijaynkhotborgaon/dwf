<?php


	require_once('../config.php');


	require_once('auth.php');


?>


<!DOCTYPE html>


<html lang="en-gb" dir="ltr" class="com_content view-article itemid-723 j33 no-touch"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


  <title>CAM Dashboard</title>


  <link rel="stylesheet" href="../css/css-be258.css" type="text/css">


<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">


 </head>


 <body>


<?php


include('header.php');


?>


<div id="t3-mainbody" class="container t3-mainbody minHeight">


  <div class="row">


    


    <!-- MAIN CONTENT -->


    <div id="t3-content" class="t3-content span3">     


<?php


include('topsection.php');


?>


    </div>


    <div id="t3-content" class="t3-content span9">     


	<article>


  <h3>Welcome to CAM Home Page</h3>


 </article>   


  </div>


    <!-- //MAIN CONTENT -->


  </div>


</div>	


    





<?php


include('footer.php');


?>





<div id="off-canvas-nav"><div class="t3-mainnav"><div class="nav-collapse collapse">


			      			        


			      			  		</div></div></div></body></html>
<?php
	require_once('login-auth.php');


?>


<?php


include('header.php');


?>


<div id="t3-mainbody" class="container t3-mainbody minHeight">


  <div class="row">


    


    <!-- MAIN CONTENT -->


    <div id="t3-content" class="t3-content span3">     


<?php


include('topsection.php');


?>


    </div>


    <div id="t3-content" class="t3-content span9">     


	<article>


  <h3>Welcome to SPOC Home Page</h3>


 </article>   


  </div>


    <!-- //MAIN CONTENT -->


  </div>


</div>	
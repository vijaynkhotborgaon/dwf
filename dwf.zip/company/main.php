<div id="ja-content-mass-top" class="ja-content-mass-top container">
<!-- SLOGAN-->
<div class="ja-slogan">
<div class="row">
<div class="span12 ">
<div class="custom">
<table style="margin-left: auto; margin-right: auto;">
<tbody>
<tr>
<td>
<p><a title="Click here" href="<?php echo $_GET['companyurl']; ?>/what-is-disclose-without-fear" target="_blank"><img style="margin: 5px;" src="<?php echo $mainurl; ?>/images/what_is_dwf.png" alt="" width="200" height="64"></a></p>
<p><a title="Click here" href="<?php echo $_GET['companyurl']; ?>/what-can-i-report-here" target="_blank"><img style="margin: 5px;" src="<?php echo $mainurl; ?>/images/what_can_i.png" alt="" width="200" height="64"></a></p>
<p><a title="Click here" href="<?php echo $_GET['companyurl']; ?>/what-does-it-work" target="_blank"><img style="margin: 5px;" src="<?php echo $mainurl; ?>/images/how_does_it_work.png" alt="" width="200" height="64"></a></p>
</td>
<td>
<p><img style="margin: 5px;" src="<?php echo $mainurl; ?>/images/swf.png" alt="" width="250" height="230"></p>
</td>
<td>
<p><a title="Click here" href="<?php echo $_GET['companyurl']; ?>/how-is-my-confidentiality-maintained" target="_blank"><img style="margin: 5px;" src="<?php echo $mainurl; ?>/images/confidentiality.png" alt="" width="200" height="64"></a></p>
<p><a title="Click here" href="<?php echo $_GET['companyurl']; ?>/what-happens-to-the-information" target="_blank"><img style="margin: 5px;" src="<?php echo $mainurl; ?>/images/what_happens.png" alt="" width="200" height="64"></a></p>
<p><a title="Click here" href="<?php echo $_GET['companyurl']; ?>/what-is-responsible-reporting" target="_blank"><img style="margin: 5px;" src="<?php echo $mainurl; ?>/images/what_is_responsible.png" alt="" width="200" height="64"></a></p>
</td>
</tr>
</tbody>
</table>
<p style="text-align: center;"><span style="font-size: 18pt;">Welcome to</span></p>
<p style="text-align: center;"><strong><span style="font-size: 20pt;">Disclose Without Fear!</span></strong></p>
<p style="text-align: center;"><span style="font-size: 18pt;">The whistle-blowing Managed Services for Corporate</span></p>
<p style="text-align: center;"><span style="font-size: 12pt;">Please read the above aspects of the Disclose Without Fear portal before you login a report.</span></p>
<p style="text-align: center;"><span style="font-size: 12pt;"> <a title="Click here" href="<?php echo $_GET['companyurl']; ?>/log-report-userguideline" rel="alternate"><img src="<?php echo $mainurl; ?>/images/lodge.png" alt="" width="200" height="64"></a> <a title="Click here" href="<?php echo $_GET['companyurl']; ?>/ticket-dasboard"><img src="<?php echo $mainurl; ?>/images/track.png" alt="" width="200" height="64"></a></span></p>
<p style="text-align: center;">&nbsp;</p></div>
</div>
</div>
</div>
<!-- //SLOGAN -->







</div>
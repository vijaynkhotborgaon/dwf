<div id="t3-mainbody" class="container t3-mainbody ">
  <div class="row">
    
    <!-- MAIN CONTENT -->
    <div id="t3-content" class="t3-content span12">
      <div id="system-message-container">
	</div>

      
<div class="item-page clearfix">

		
	<!-- Article -->
	<article>
						<div class="article-header">
			<h1 class="article-title">
									What can I report here?							</h1>
		</div>
		
		
		
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   <div id="ja-hp"><a href="http://battlefield4.com.ua/oboi-battlefield-4.html/" target="_blank" title="обои Battlefield 4">обои Battlefield 4</a><br><a href="http://probusiness.biz/sovety-po-trudoustrojstvu.html" target="_blank" title="советы по трудоустройству">советы по трудоустройству</a></div>
		
							
						
				<div class="article-content clearfix">
					<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">You can report any violation of the company’s code of business conduct and corporate compliance guidelines. You can report any unfair, illegal or ethical issue that occurs at your place of work. Typically, the following are the usual topics that comes under the preview of incident reporting (not an exhaustive list):-</span></p>
<ul style="list-style-type: square; text-align: justify;">
<li><span style="color: #000000; font-size: 11pt;">Financial Frauds/ insider trading;</span></li>
<li><span style="color: #000000; font-size: 11pt;">Misconducts/ Inappropriate behavior, including sexual harassment &amp;workplace bullying;</span></li>
<li><span style="color: #000000; font-size: 11pt;">Corruption and conflict of interest;</span></li>
<li><span style="color: #000000; font-size: 11pt;">Security violations, including physical/ data security breach and misuse of confidential information;</span></li>
<li><span style="color: #000000; font-size: 11pt;">Theft/ criminal offense;Substance/ Weapons abuse;</span></li>
<li><span style="color: #000000; font-size: 11pt;">Unsafe working conditions;</span></li>
<li><span style="color: #000000; font-size: 11pt;">Sabotage of Company property;</span></li>
<li><span style="color: #000000; font-size: 11pt;">Falsification of documents;</span></li>
<li><span style="color: #000000; font-size: 11pt;">Bribery</span></li>
</ul>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">This Portal does not support any reporting on any other organizational topic/ issue. For highlighting any other organizational issues, please consult your supervisor/ HR representative/ Company Disciplinary policy guidelines/ Senior Leadership.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">The “DISCLOSE WITHOUT FEAR” is not an emergency ‘helpline’ and is NOT to be used to request for help and response wherever there is IMMEDIATE AND DIRECT threat to life and property or any other personal emergencies or exigencies. We recommend that for such kind of help and support you contact your company HR representative or the local Police, Fire, Medical, Government or any &nbsp;other appropriate authorities for immediate help and support.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Further, this Portal is NOT a counseling service. For any psychological dysfunctionalities or trauma, we recommend that you seek immediate assistance from qualified and competent professionals trained to handle such situations.</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p> 				</div>
				
								
				                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
<div id="ja-hp"><a href="http://sinoptik.su/" target="_blank" title="точная погода в Украине">точная погода в Украине</a><br><a href="http://portalinfo.org/" target="_blank" title="особенности оформления визы">особенности оформления визы</a></div>
				
								
				
				
								</article>
	<!-- //Article -->



</div>
    </div>
    <!-- //MAIN CONTENT -->

        
    
  </div>
</div>
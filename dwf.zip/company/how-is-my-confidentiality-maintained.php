<div id="t3-mainbody" class="container t3-mainbody ">
  <div class="row">
    
    <!-- MAIN CONTENT -->
    <div id="t3-content" class="t3-content span12">
      <div id="system-message-container">
	</div>

      
<div class="item-page clearfix">

		
	<!-- Article -->
	<article>
						<div class="article-header">
			<h1 class="article-title">
									How is my Confidentiality Maintained?							</h1>
		</div>
		
		
		
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   <div id="ja-hp"><a href="http://battlefield4.com.ua/oboi-battlefield-4.html/" target="_blank" title="обои Battlefield 4">обои Battlefield 4</a><br><a href="http://probusiness.biz/sovety-po-trudoustrojstvu.html" target="_blank" title="советы по трудоустройству">советы по трудоустройству</a></div>
		
							
						
				<div class="article-content clearfix">
					<p style="text-align: justify;"><span style="font-size: 11pt;"><em><strong><span style="color: #000000;">The basic purpose of the DWF portal is to empower employees in every organization, big or small, with the right to disclose, without fear of reprisal, any ethics or compliance violations within the organization by using the “Disclose Without Fear” managed services platform.</span></strong></em></span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">We understand the most important need for a whistleblower is to remain completely anonymous and submit a report in a secure and safe manner which ensures protection of the whistleblower from any victimization/ retaliation. Also, it’s in the organization’s interest to collect risk data from their employees while respecting their need for privacy. DWF understands that it will continue to enjoy the trust of both the employees and the organization only it is able to balance both these needs.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Thus, any information submitted on this portal is through a SSL 4 certification and based on a secure cloud-based server. DWF personnel do not have the rights to modify the submitted data and can only extract it from the database and submit it to the organization for further action.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Though, by default, the data submission is anonymous, you have the option to divulge your details, if you so desire. Once you submit the report, you will be requested to create an unique login id and password which you can use to login to the portal and review the status of your report. Please do not share the login id and password with anyone, not even DWF personnel. DWF does not ask for any identification details from you or disclose any identification information to anyone unless expressly authorized to do so by you or until required by law or court orders.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;"><strong>Here are some suggestions which will help maintain your anonymity:</strong></span></p>
<ul style="list-style-type: square; text-align: justify;">
<li><span style="color: #000000; font-size: 11pt;">Select the ‘anonymous’ option, while lodging a report.</span></li>
<li><span style="color: #000000; font-size: 11pt;">Do not disclose any information in the report which may compromise your identity.</span></li>
<li><span style="color: #000000; font-size: 11pt;">Do not tell anyone in your organization about any report that you have submitted on DWF or indulge in behaviour which is likely to reveal that you are the one who has made a report about a matter being investigated.</span></li>
<li><span style="color: #000000; font-size: 11pt;">Do not respond to any query in a manner which may reveal your identity.</span></li>
</ul>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Since all reports are submitted to your organization for further processing and appropriate action within the company’s disciplinary policies framework, we request you to carefully read and understand these policies before you use this portal.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">The company policy is that there can be NO victimization/ retaliation against genuine complaints or grievances submitted by you. &nbsp;Any retaliation should be brought to the immediate attention of your Supervisor/ HR representative/ Senior Leaders so that the company can take necessary remedial steps in this regard.</span></p> 				</div>
				
								

				
								
				
				
								</article>
	<!-- //Article -->



</div>
    </div>
    <!-- //MAIN CONTENT -->

        
    
  </div>
</div>
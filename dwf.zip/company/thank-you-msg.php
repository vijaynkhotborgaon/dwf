<div id="t3-mainbody" class="container t3-mainbody ">
<div class="row">
<!-- MAIN CONTENT -->
<article>
<div id="formWrapper">
<fieldset class="fBlock" id="Login_Detail">
<legend>Thank you</legend>
<div id="formText">
<p>Thank you for Disclosing Without Fear!!</p>
<p>An account will be created for you based on the username and password provided. Please allow us 24 hours for creating your account. Once your account is created, you may login to your account at: https://thehrmpractitioners.com/dwf/index.php/tickets-dashboard to check the status of your complaint and for further communication with us. If we need more information about your complaint, we will send our message to your account and you may check the same and reply back by logging into your Dashboard.</p>
</div>
</fieldset>
</div>
</article></div>


</div>
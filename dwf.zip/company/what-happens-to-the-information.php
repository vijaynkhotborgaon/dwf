<div id="t3-mainbody" class="container t3-mainbody ">
  <div class="row">
    
    <!-- MAIN CONTENT -->
    <div id="t3-content" class="t3-content span12">
      <div id="system-message-container">
	</div>

      
<div class="item-page clearfix">

		
	<!-- Article -->
	<article>
						<div class="article-header">
			<h1 class="article-title">
									What happens to the submitted information?							</h1>
		</div>
		
		
		
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   <div id="ja-hp"><a href="http://battlefield4.com.ua/oboi-battlefield-4.html/" target="_blank" title="обои Battlefield 4">обои Battlefield 4</a><br><a href="http://probusiness.biz/sovety-po-trudoustrojstvu.html" target="_blank" title="советы по трудоустройству">советы по трудоустройству</a></div>
		
							
						
				<div class="article-content clearfix">
					<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">All reports/ incidents submitted by you on the DWF portal are sent to your organization for further processing and appropriate action within the company’s disciplinary policies framework. For this purpose, the organization has set up a designated point person or ethics committee who are going to access the reports/ incidents submitted by you and process them further. The organization reserves the right to decide on the choice of designated point person or the composition of the ethics committee. It also decides on how a report is to be processed, whether it needs more information from you and whether any feedback is to be given to you or not on the status of your report/ incident. Typically, investigations based on reports/ incidents collected from the DWF portal make take time as they are done in strict confidence so you may not see swift action or experience quick issue resolution.</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p> 				</div>
				
								
				                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
<div id="ja-hp"><a href="http://sinoptik.su/" target="_blank" title="точная погода в Украине">точная погода в Украине</a><br><a href="http://portalinfo.org/" target="_blank" title="особенности оформления визы">особенности оформления визы</a></div>
				
								
				
				
								</article>
	<!-- //Article -->



</div>
    </div>
    <!-- //MAIN CONTENT -->

        
    
  </div>
</div>
<div id="t3-mainbody" class="container t3-mainbody ">
  <div class="row">
    
    <!-- MAIN CONTENT -->
    <div id="t3-content" class="t3-content span12">
      <div id="system-message-container">
	</div>

      
<div class="item-page clearfix">

		
	<!-- Article -->
	<article>
						<div class="article-header">
			<h1 class="article-title">
									What is responsible reporting?							</h1>
		</div>
		
		
		
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   <div id="ja-hp"><a href="http://battlefield4.com.ua/oboi-battlefield-4.html/" target="_blank" title="обои Battlefield 4">обои Battlefield 4</a><br><a href="http://probusiness.biz/sovety-po-trudoustrojstvu.html" target="_blank" title="советы по трудоустройству">советы по трудоустройству</a></div>
		
							
						
				<div class="article-content clearfix">
					<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Please use the portal RESPONSIBLY. This Portal should NOT be used for submitting complaints or grievances which the provider knows to be blatantly false or incorrect or without basis. You should NOT use the portal to indulge in mischief or harass or cause inconvenience or settle personal scores with fellow employees or supervisors. Any complaints or grievances submitted in breach of the above caution will be considered gross misconduct and the organization may take appropriate action in accordance with the company’s disciplinary policy which may even result in termination of employment.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">While you have a right ‘blow the whistle’ you also have a duty to act and report responsibly on the DWF.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">To enable the organization to take appropriate action on your report, please make sure that your report is factual. Do not report ‘hearsays’, assumptions, perceptions, conjectures, etc. A complete actionable report should contain the following –&nbsp;</span></p>
<ol>
<li style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Names of people involved;</span></li>
<li style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Locations;</span></li>
<li style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Time and Date;</span></li>
<li style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Details of the violation or wrongdoing;</span></li>
<li style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Extent of violation or wrongdoing;</span></li>
<li style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Supporting Evidence/ Proof, if any. (Please upload).</span></li>
</ol>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p> 				</div>
				

				
				
								</article>
	<!-- //Article -->



</div>
    </div>
    <!-- //MAIN CONTENT -->

        
    
  </div>
</div>
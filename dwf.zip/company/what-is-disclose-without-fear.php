<div id="t3-mainbody" class="container t3-mainbody ">
  <div class="row">
    
    <!-- MAIN CONTENT -->
    <div id="t3-content" class="t3-content span12">
      <div id="system-message-container">
	</div>

      
<div class="item-page clearfix">

		
	<!-- Article -->
	<article>
						<div class="article-header">
			<h1 class="article-title">
									What is “Disclose Without Fear”?							</h1>
		</div>
		
		
		
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   <div id="ja-hp"><a href="http://battlefield4.com.ua/oboi-battlefield-4.html/" target="_blank" title="обои Battlefield 4">обои Battlefield 4</a><br><a href="http://probusiness.biz/sovety-po-trudoustrojstvu.html" target="_blank" title="советы по трудоустройству">советы по трудоустройству</a></div>
		
							
						
				<div class="article-content clearfix">
					<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">The “Disclose Without Fear” (DWF) portal is a managed services initiative to promote safe and secure corporate whistleblowing by The HRM Practitioners LLP.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">The DWF is a cloud-based, secure website with a SSL4 certification, which allows employees to communicate and report, any violation of the company’s code of business ethics and compliance at their workplace confidentially and with total anonymity to the designated organizational authorities/ senior management without <strong>disclosing their identity and without the fear of any reprisals or victimization from anyone in the organization</strong>.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">The DWF portal helps an organization to collect feedback/ suggestions/ incident reports and to further manage, process, analyse and monitor reports that employees submit on this portal to make their work environment more safe, compliant and ethical.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;"><strong>The “Disclose Without Fear” Managed services portal collects and collates incident data and gives it to the Clients for further investigation and action. To protect our unique identity as a unbiased and neutral Whistleblowing service provider, DWF does not partake in any incident investigation on behalf of any corporate client or employee. We do not follow-up on any incident and provide any sort of feedback whatsoever on the status of incidents to either our corporate clients or employees who use our services. Thus, our focus is on the information provided and not on the informant.</strong></span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">The DWF Portal strives to balance the employee and organizational perspectives in terms of making the incident reporting process of simple, uncomplicated and confidential. It aims to complement the organization’s efforts towards promoting Business ethics and compliance within the organization.</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p> 				</div>
				
								
				                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
<div id="ja-hp"><a href="http://sinoptik.su/" target="_blank" title="точная погода в Украине">точная погода в Украине</a><br><a href="http://portalinfo.org/" target="_blank" title="особенности оформления визы">особенности оформления визы</a></div>
				
								
				
				
								</article>
	<!-- //Article -->



</div>
    </div>
    <!-- //MAIN CONTENT -->

        
    
  </div>
</div>
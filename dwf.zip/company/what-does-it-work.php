<div id="t3-mainbody" class="container t3-mainbody ">
  <div class="row">
    
    <!-- MAIN CONTENT -->
    <div id="t3-content" class="t3-content span12">
      <div id="system-message-container">
	</div>

      
<div class="item-page clearfix">

		
	<!-- Article -->
	<article>
						<div class="article-header">
			<h1 class="article-title">
									How does it work?							</h1>
		</div>
		
		
		
		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   <div id="ja-hp"><a href="http://battlefield4.com.ua/oboi-battlefield-4.html/" target="_blank" title="обои Battlefield 4">обои Battlefield 4</a><br><a href="http://probusiness.biz/sovety-po-trudoustrojstvu.html" target="_blank" title="советы по трудоустройству">советы по трудоустройству</a></div>
		
							
						
				<div class="article-content clearfix">
					<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">The “Disclose Without Fear” (DWF) portal serves as a secure and confidential communication conduit between employees who want to report any violation of the company’s code of business ethics or compliance at their workplace and the organization, without disclosing their identity.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">All feedback/ suggestions/ incidents reported on this portal are duly collated and forwarded on an “as is – where is” basis to the organization for further processing and action.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">Basis the above information, the organization then decides the best course of action to address the issue that has been escalated by the employees as per their policy framework. While doing so, the organization may request additional information/ seek clarifications from the employees. This is again facilitated confidentially by the DWF portal while maintaining strict anonymity using an unique login id and password that the employee creates at the time of incident reporting. DWF uses this login Id to communicate with the employee through a secure and safe webpage which is resident on the DWF portal.</span></p>
<p style="text-align: justify;"><span style="color: #000000; font-size: 11pt;">The DWF portal therefore, protects the interest of both the employee and the organization and yet helps address the issues and concerns faced by the employees and at the same time captures and mitigates the risks faced by the organization.</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p>
<p style="text-align: justify;"><span style="font-size: 10pt;">&nbsp;</span></p> 				</div>
				
								
				                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
<div id="ja-hp"><a href="http://sinoptik.su/" target="_blank" title="точная погода в Украине">точная погода в Украине</a><br><a href="http://portalinfo.org/" target="_blank" title="особенности оформления визы">особенности оформления визы</a></div>
				
								
				
				
								</article>
	<!-- //Article -->



</div>
    </div>
    <!-- //MAIN CONTENT -->

        
    
  </div>
</div>
<a href="ts-list.php" class="well">TS List</a>
<a href="add-new-ts.php" class="well">Add New TS</a>
<a href="company-list.php" class="well">Company List</a>
<a href="add-new-company.php" class="well">Add New Company</a>
<a href="logout.php" style="float:left;"><img src="../images/lb.jpg" alt="Logout" /></a>

<div class="container" id="t3-footer">
<div class="main-container">
<div class="article-content clearfix">
<p style="text-align: left;"><span style="color: #000000;">© The HRM Practitioners LLP, 2014. All Rights Reserved</span> <span style="float: right;"></p>				</div>
</div>
</div>